function addSale() {
  let product = document.getElementById("product").value;
  let amount = document.getElementById("amount").value;
  
  if (product === "" || amount === "") return;
  
  let li = document.createElement("li");
  li.textContent = product + " - $" + amount;
  
  document.getElementById("salesList").appendChild(li);
}